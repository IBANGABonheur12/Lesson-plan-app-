function showMessage() {
  alert("Hello from GitHub! 🚀");
}